# -*- coding: utf-8 -*-


class InvalidVersionException(Exception):
    pass
