# -*- coding: utf-8 -*-


class StaleKeyExchangeException(Exception):
    pass
