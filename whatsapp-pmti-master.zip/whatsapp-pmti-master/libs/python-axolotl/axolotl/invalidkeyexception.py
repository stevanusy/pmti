# -*- coding: utf-8 -*-


class InvalidKeyException(Exception):
    pass
