# -*- coding: utf-8 -*-

__version__ = '0.1.39'
__author__ = 'Tarek Galal'
__email__ = 'tare2.galal@gmail.com'
__license__ = 'GPLv3'
__status__ = 'Production'
