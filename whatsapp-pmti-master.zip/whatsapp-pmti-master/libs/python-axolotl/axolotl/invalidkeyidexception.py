# -*- coding: utf-8 -*-


class InvalidKeyIdException(Exception):
    pass
