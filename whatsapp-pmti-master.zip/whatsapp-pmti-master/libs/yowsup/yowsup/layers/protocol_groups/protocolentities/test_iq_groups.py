from yowsup.layers.protocol_iq.protocolentities.test_iq import IqProtocolEntityTest

class GroupsIqProtocolEntityTest(IqProtocolEntityTest):
    pass
