from app.mac import mac, signals
from app.utils import helper

import time

'''
Signals this module listents to:
1. When a message is received (signals.command_received)
==========================================================
'''
@signals.message_received.connect
def handle(message):
    if message.text == "Halo sayang":

      while True:
        #### Delay for 1 seconds ####
        time.sleep(1)

        ### Show today's date and time ##
        sayang(message)

        break;
      
    if message.text == "Iya dong kan kangen":
        kangen(message)

'''
Actual module code
==========================================================
'''
def sayang(message):
    answer = "Halo jugaa 😝"
    mac.send_message(answer, message.conversation)

    answer = "Eh tumben ngechat duluan 🤨"
    mac.send_message(answer, message.conversation)

def kangen(message):
    answer = "Ah kamu.. hayu ajak aku nonton dong 😋"
    mac.send_message(answer, message.conversation)

    answer = "Bosen nih :("
    mac.send_message(answer, message.conversation)