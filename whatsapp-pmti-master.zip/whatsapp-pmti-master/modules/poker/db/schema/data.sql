-- Players
insert into players values(1, "Leind", 20, "5218114140740");
insert into players values(2, "Lucas", 20, "5218116133161");
insert into players values(3, "Pepe", 20, "5218110112681");
insert into players values(4, "Rob", 20, "5218123869192");
insert into players values(5, "Art", 20, "5218181162093");
insert into players values(6, "Fab", 20, "5218110117106");
insert into players values(7, "Luis", 20, "18325673741");
insert into players values(8, "Aaron", 20, "5218116559100");
insert into players values(9, "Berni", 20, "5218116616897");
insert into players values(10, "Nayo", 20, "5218116635862");
insert into players values(11, "Casta", 20, "5218114901244");
insert into players values(12, "Chad", 20, "5218123198861");
insert into players values(13, "Cesar", 20, "5218113465239");
insert into players values(14, "Roli", 20, "5218119098536");
insert into players values(15, "Kof", 20, "5218111834751");
insert into players values(16, "Dany", 20, "5218120749543");