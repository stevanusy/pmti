# Add here the modules you want to enable here
from modules import hiExample
from modules import poker
from modules import pacaran
from modules import report
