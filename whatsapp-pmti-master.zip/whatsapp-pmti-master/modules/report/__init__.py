from app.mac import mac, signals
from app.utils import helper

'''
Signals this module listents to:
1. When a message is received (signals.command_received)
==========================================================
'''
@signals.command_received.connect
def handle(message):
    helper.log(message)
    if message.command == "report":
        report(message)

'''
Actual module code
==========================================================
'''
def report(message):
    employee_id = message.predicate.split(' ')[0]
    answer = ""

    # cek kalau ada employee_id
    if employee_id:
        # cari ke db dengan employee id
        if employee_id == "weaving-3":
            answer = "*REPORT Bulan Juni 2019* \n Performa mesin paling buruk 🤖: A-52314 \n Total produksi: 2000000 yard \n Grade A: 70% 😍 \n Grade B: 30% \n\n Grade A, meningkat 30% dari minggu lalu \n Mantap, tingkatkan terus ya...😄"
        
        elif employee_id == "weaving-5":
            answer = "*REPORT Bulan Juni 2019* \n Performa mesin paling buruk 🤖: B-10242 \n Total produksi: 1000000 yard \n Grade A: 30% \n Grade B: 70% 😔 \n\n Grade B, meningkat 20% dari minggu lalu \n Ayo dong tingkating gradenya 😄"
        
        else:
            answer = "Employee id tidak ditemukan"

    else:
        answer = "Mohon masukkan employee id"
      
    mac.send_message(answer, message.conversation)