#!/usr/bin/env bash
find / -name 'axolotl.db' -exec rm -rf {} \;